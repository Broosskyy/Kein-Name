# Mutation Boss — M01.5

Small browser-first vertical slice for the loop: attack → boss breakpoint → essence → visible creature mutation → changed attack → final evolution → retry.

## Start

```bash
npm install
npm run dev
```

Open the printed local URL. Use a phone on the same network with the host machine's LAN address for a real-device check.
Use `npm run dev:local` in an environment that does not expose network interfaces.

## Build and tests

```bash
npm test
npm run build
npm run preview
```

## Controls

- Auto attack runs continuously.
- Tap/click **POWER HIT** when ready.
- Press `D` or backtick in development to toggle the debug controls.
- Debug controls can also be shown with `?debug=1`.

## M01 / M01.5 scope

- One procedural boss and creature
- Auto attack and active Power Hit
- Crystal at 70%, Void at 40%, Wings at 0%
- Mutations visibly alter the creature and attacks
- Final evolution reveal and restart without a page reload
- Portrait-first responsive layout with landscape composition
- Medium quality profile and pooled particles/projectiles
- Small procedural Web Audio hook after the first user interaction
- Mobile lifecycle handling: background pause, time-safe resume, resize and orientation changes
- Data-driven definitions for the current boss and three mutations
- Optional asset manifest with procedural fallbacks
- Serializable run contract and a small domain-event boundary

## Project structure

- `src/core/CombatModel.ts` — deterministic run/combat state
- `src/core/DomainEvents.ts` — small synchronous gameplay-event boundary
- `src/content.ts` — current boss and mutation definitions
- `src/assets.ts` — optional asset manifest/loader with procedural fallbacks
- `src/config.ts` — balance, timings and quality settings
- `src/platform/AppLifecycle.ts` — browser pause/resume and resize lifecycle
- `src/render/GameScene.ts` — Pixi scene, animation and orchestration
- `src/render/EffectsLayer.ts` — pooled particles, damage numbers and shockwaves
- `src/ui/GameUI.ts` — DOM HUD, result and development controls
- `src/audio/AudioBus.ts` — optional procedural audio interface
- `src/online/RunSubmissionPort.ts` — interface only; no network implementation

## Known limitations

- Art is intentionally procedural and will later accept a real boss hero asset.
- Web Audio starts only after a user gesture due to browser policy.
- Landscape is recomposed from the same gameplay scene rather than using separate art.
- Lifecycle and pause compensation are covered at domain level; Android app switching, final feel and sustained frame rate still require real hardware validation.

## Mobile test notes

Test Chrome on an average Android phone in both orientations. Confirm that Power Hit remains clear of system safe areas, the browser does not scroll/zoom, app switching freezes the run timer/cooldowns, repeated retries work, and effects stay above 30 FPS. Lower `quality.active` in `src/config.ts` if fill rate or particles are excessive.

Optional real assets are configured in `src/assets.ts`. Empty entries deliberately retain the procedural M01 visuals, so visual polish can be introduced one asset at a time without making art a startup dependency.

## Future online boundary

M01.5 sends and stores nothing. `RunContract` is a JSON-safe UI/render-independent result, and `RunSubmissionPort` is deliberately an unimplemented future boundary. Competitive rankings, global boss HP/damage, ranked rewards and economy must later be validated or calculated server-side; client-submitted values must never be trusted directly.
