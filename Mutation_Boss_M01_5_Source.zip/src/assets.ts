import { Assets, Texture } from 'pixi.js';

export type AssetKey =
  | 'boss.hero'
  | 'background.arena'
  | 'mutations.crystal'
  | 'mutations.void'
  | 'mutations.wings'
  | 'loot.crystal'
  | 'loot.void'
  | 'loot.wings'
  | 'ui.powerHit';

export interface AssetEntry {
  src?: string;
  fallback: 'procedural';
}

export type AssetManifest = Readonly<Record<AssetKey, AssetEntry>>;

// Add a local source path when final art exists. Missing assets always keep the
// current procedural visuals alive.
export const ASSET_MANIFEST: AssetManifest = {
  'boss.hero': { fallback: 'procedural' },
  'background.arena': { fallback: 'procedural' },
  'mutations.crystal': { fallback: 'procedural' },
  'mutations.void': { fallback: 'procedural' },
  'mutations.wings': { fallback: 'procedural' },
  'loot.crystal': { fallback: 'procedural' },
  'loot.void': { fallback: 'procedural' },
  'loot.wings': { fallback: 'procedural' },
  'ui.powerHit': { fallback: 'procedural' },
};

export class AssetRegistry {
  private readonly textures = new Map<AssetKey, Texture>();

  constructor(private readonly manifest: AssetManifest = ASSET_MANIFEST) {}

  async preload(): Promise<void> {
    const configured = Object.entries(this.manifest).filter((entry): entry is [AssetKey, AssetEntry & { src: string }] => Boolean(entry[1].src));
    await Promise.all(configured.map(async ([key, entry]) => {
      try {
        this.textures.set(key, await Assets.load<Texture>(entry.src));
      } catch (error) {
        console.warn(`Asset ${key} could not be loaded; using procedural fallback.`, error);
      }
    }));
  }

  texture(key: AssetKey): Texture | undefined {
    return this.textures.get(key);
  }
}
