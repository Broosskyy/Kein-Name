export type SoundCue =
  | 'normalAttack'
  | 'powerHit'
  | 'bossImpact'
  | 'breakpoint'
  | 'essenceAbsorb'
  | 'mutation'
  | 'finalReveal';

export interface GameAudio {
  unlock(): void;
  pause(): void;
  resume(): void;
  play(cue: SoundCue): void;
}

export class ProceduralAudioBus implements GameAudio {
  private context?: AudioContext;
  private enabled = true;

  unlock(): void {
    if (!this.enabled) return;
    try {
      this.context ??= new AudioContext();
      void this.context.resume();
    } catch {
      this.enabled = false;
    }
  }

  pause(): void {
    if (this.context?.state === 'running') void this.context.suspend().catch(() => undefined);
  }

  resume(): void {
    if (this.context?.state === 'suspended') void this.context.resume().catch(() => undefined);
  }

  play(cue: SoundCue): void {
    const context = this.context;
    if (!context || context.state !== 'running' || !this.enabled) return;
    const presets: Record<SoundCue, [number, number, number, OscillatorType]> = {
      normalAttack: [380, 590, 0.06, 'sine'],
      powerHit: [130, 58, 0.18, 'sawtooth'],
      bossImpact: [85, 42, 0.1, 'square'],
      breakpoint: [210, 720, 0.38, 'triangle'],
      essenceAbsorb: [330, 880, 0.28, 'sine'],
      mutation: [440, 1040, 0.42, 'triangle'],
      finalReveal: [220, 1320, 0.72, 'sine'],
    };
    const [start, end, duration, type] = presets[cue];
    const oscillator = context.createOscillator();
    const gain = context.createGain();
    const now = context.currentTime;
    oscillator.type = type;
    oscillator.frequency.setValueAtTime(start, now);
    oscillator.frequency.exponentialRampToValueAtTime(Math.max(20, end), now + duration);
    gain.gain.setValueAtTime(0.0001, now);
    gain.gain.exponentialRampToValueAtTime(cue === 'normalAttack' ? 0.035 : 0.075, now + 0.012);
    gain.gain.exponentialRampToValueAtTime(0.0001, now + duration);
    oscillator.connect(gain).connect(context.destination);
    oscillator.start(now);
    oscillator.stop(now + duration + 0.03);
  }
}
