export type QualityName = 'low' | 'medium' | 'high';

export const GAME_CONFIG = {
  schemaVersion: 1,
  clientVersion: '0.1.5',
  combat: {
    normalDamage: 42,
    attackIntervalMs: 950,
    powerDamage: 160,
    powerCooldownMs: 3200,
    voidEchoMultiplier: 0.34,
    voidEchoDelayMs: 150,
  },
  timing: {
    breakpointDurationMs: 2400,
    finalDurationMs: 3300,
    normalProjectileMs: 310,
    powerProjectileMs: 430,
    normalHitStopMs: 22,
    powerHitStopMs: 68,
    finalHitStopMs: 125,
  },
  quality: {
    active: 'medium' as QualityName,
    low: { dpr: 1, particles: 0.55, maxParticles: 70, maxProjectiles: 10, maxFloatingTexts: 12, maxShockwaves: 4 },
    medium: { dpr: 1.25, particles: 1, maxParticles: 130, maxProjectiles: 14, maxFloatingTexts: 18, maxShockwaves: 6 },
    high: { dpr: 1.5, particles: 1.35, maxParticles: 180, maxProjectiles: 18, maxFloatingTexts: 24, maxShockwaves: 8 },
  },
} as const;

export const ACTIVE_QUALITY = GAME_CONFIG.quality[GAME_CONFIG.quality.active];
