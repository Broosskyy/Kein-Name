import { describe, expect, it } from 'vitest';
import { ASSET_MANIFEST } from './assets';
import { ACTIVE_BOSS, MUTATIONS } from './content';

describe('M01.5 content and asset boundary', () => {
  it('defines one valid boss and exactly the three M01 mutations', () => {
    expect(ACTIVE_BOSS.maxHp).toBeGreaterThan(0);
    expect(ACTIVE_BOSS.weakpoint).toEqual(expect.objectContaining({ x: expect.any(Number), y: expect.any(Number) }));
    expect(MUTATIONS.map((mutation) => mutation.id)).toEqual(['crystal', 'void', 'wings']);
    expect(MUTATIONS.map((mutation) => mutation.breakpoint)).toEqual([0.7, 0.4, 0]);
  });

  it('provides procedural fallback entries for every configured visual', () => {
    expect(ASSET_MANIFEST[ACTIVE_BOSS.visualKey].fallback).toBe('procedural');
    for (const mutation of MUTATIONS) {
      expect(ASSET_MANIFEST[mutation.visualKey].fallback).toBe('procedural');
      expect(ASSET_MANIFEST[`loot.${mutation.id}`].fallback).toBe('procedural');
    }
  });
});
