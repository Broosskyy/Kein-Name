import type { Mutation } from './types';

export interface BossDefinition {
  id: string;
  name: string;
  maxHp: number;
  weakpoint: { x: number; y: number };
  visualKey: 'boss.hero';
}

export interface MutationDefinition {
  id: Mutation;
  name: string;
  breakpoint: number;
  damageModifier: number;
  attackBehaviorKey: 'crystal-shot' | 'void-echo' | 'final-evolution';
  visualKey: 'mutations.crystal' | 'mutations.void' | 'mutations.wings';
}

export const ACTIVE_BOSS: BossDefinition = {
  id: 'fractured-colossus-m01',
  name: 'Fractured Colossus',
  maxHp: 3200,
  weakpoint: { x: 0, y: 8 },
  visualKey: 'boss.hero',
};

export const MUTATIONS: readonly MutationDefinition[] = [
  {
    id: 'crystal',
    name: 'Crystal',
    breakpoint: 0.7,
    damageModifier: 1.22,
    attackBehaviorKey: 'crystal-shot',
    visualKey: 'mutations.crystal',
  },
  {
    id: 'void',
    name: 'Void',
    breakpoint: 0.4,
    damageModifier: 1,
    attackBehaviorKey: 'void-echo',
    visualKey: 'mutations.void',
  },
  {
    id: 'wings',
    name: 'Wings',
    breakpoint: 0,
    damageModifier: 1,
    attackBehaviorKey: 'final-evolution',
    visualKey: 'mutations.wings',
  },
] as const;

export const MUTATION_BY_ID: Readonly<Record<Mutation, MutationDefinition>> = Object.fromEntries(
  MUTATIONS.map((mutation) => [mutation.id, mutation]),
) as Record<Mutation, MutationDefinition>;
