import { describe, expect, it } from 'vitest';
import { GAME_CONFIG } from '../config';
import { ACTIVE_BOSS, MUTATION_BY_ID } from '../content';
import type { GameDomainEvent } from './DomainEvents';
import { CombatModel } from './CombatModel';

function damageUntil(model: CombatModel, threshold: number, now = 1000): number {
  while (model.bossHp / model.maxHp > threshold && model.phase === 'playing') {
    model.attack('normal', now++);
  }
  return now;
}

function completeRun(model: CombatModel, now = 1000): number {
  now = damageUntil(model, 0.7, now);
  model.completeMutation('crystal', now++);
  now = damageUntil(model, 0.4, now);
  model.completeMutation('void', now++);
  now = damageUntil(model, 0, now);
  model.completeMutation('wings', now++);
  return now;
}

function containsNonPlainValue(value: unknown): boolean {
  if (value === null || ['string', 'number', 'boolean'].includes(typeof value)) return false;
  if (Array.isArray(value)) return value.some(containsNonPlainValue);
  if (typeof value !== 'object' || Object.getPrototypeOf(value) !== Object.prototype) return true;
  return Object.values(value as Record<string, unknown>).some(containsNonPlainValue);
}

describe('CombatModel', () => {
  it('initializes and lowers boss HP', () => {
    const model = new CombatModel(100);
    expect(model.phase).toBe('playing');
    const hit = model.attack('normal', 1000);
    expect(hit.accepted).toBe(true);
    expect(model.bossHp).toBeLessThan(model.maxHp);
  });

  it('triggers each breakpoint exactly once and reaches result', () => {
    const model = new CombatModel(0);
    let now = damageUntil(model, 0.7);
    expect(model.triggered.has('crystal')).toBe(true);
    expect(model.triggered.size).toBe(1);
    expect(model.attack('normal', now).accepted).toBe(false);
    model.completeMutation('crystal');
    expect(model.mutations.has('crystal')).toBe(true);

    now = damageUntil(model, 0.4, now);
    expect(model.triggered.has('void')).toBe(true);
    expect(model.triggered.size).toBe(2);
    model.completeMutation('void');
    expect(model.mutations.has('void')).toBe(true);

    now = damageUntil(model, 0, now);
    expect(model.triggered.has('wings')).toBe(true);
    expect(model.triggered.size).toBe(3);
    model.completeMutation('wings');
    expect(model.mutations.has('wings')).toBe(true);
    expect(model.phase).toBe('result');
  });

  it('enforces power hit cooldown', () => {
    const model = new CombatModel(0);
    expect(model.attack('power', 1000).accepted).toBe(true);
    expect(model.attack('power', 1001).accepted).toBe(false);
    expect(model.attack('power', 1000 + GAME_CONFIG.combat.powerCooldownMs).accepted).toBe(true);
  });

  it('retry resets the complete run state', () => {
    const model = new CombatModel(0);
    const firstRunId = model.runId;
    model.attack('power', 1000);
    damageUntil(model, 0.7, 1001);
    model.completeMutation('crystal');
    model.reset(5000);
    expect(model.bossHp).toBe(model.maxHp);
    expect(model.phase).toBe('playing');
    expect(model.mutations.size).toBe(0);
    expect(model.triggered.size).toBe(0);
    expect(model.totalDamage).toBe(0);
    expect(model.powerHits).toBe(0);
    expect(model.canPowerHit(5000)).toBe(true);
    expect(model.runId).not.toBe(firstRunId);
  });

  it('development shortcuts can target later breakpoints directly', () => {
    const model = new CombatModel(0);
    const result = model.debugForceBreakpoint('wings', 500);
    expect(result.triggeredMutation).toBe('wings');
    expect(model.bossHp).toBe(0);
    expect(model.mutations.has('crystal')).toBe(true);
    expect(model.mutations.has('void')).toBe(true);
    expect(model.phase).toBe('finalizing');
  });

  it('uses boss and mutation content configuration for combat', () => {
    const model = new CombatModel(0);
    expect(model.maxHp).toBe(ACTIVE_BOSS.maxHp);
    let now = damageUntil(model, MUTATION_BY_ID.crystal.breakpoint);
    model.completeMutation('crystal', now++);
    const hit = model.attack('normal', now);
    expect(hit.damage).toBe(Math.round(GAME_CONFIG.combat.normalDamage * MUTATION_BY_ID.crystal.damageModifier));
  });

  it('freezes combat, cooldown and elapsed time while paused, then resumes', () => {
    const model = new CombatModel(1000);
    model.attack('power', 1200);
    const hpBeforePause = model.bossHp;
    const cooldownBeforePause = model.powerCooldownRemaining(1500);
    model.pause(1500);
    expect(model.attack('normal', 5000).accepted).toBe(false);
    expect(model.bossHp).toBe(hpBeforePause);
    expect(model.elapsedMs(5000)).toBe(500);
    expect(model.powerCooldownRemaining(5000)).toBe(cooldownBeforePause);
    model.resume(5000);
    expect(model.elapsedMs(5500)).toBe(1000);
    expect(model.powerCooldownRemaining(5000)).toBe(cooldownBeforePause);
    expect(model.attack('normal', 5500).accepted).toBe(true);
  });

  it('produces a plain JSON serializable run contract', () => {
    const model = new CombatModel(100, { wallClock: () => '2026-09-23T19:00:00.000Z' });
    const end = completeRun(model, 1000);
    const result = model.finish(end);
    const roundTrip = JSON.parse(JSON.stringify(result));
    expect(roundTrip).toEqual(result);
    expect(result.schemaVersion).toBe(GAME_CONFIG.schemaVersion);
    expect(result.clientVersion).toBe(GAME_CONFIG.clientVersion);
    expect(result.bossId).toBe(ACTIVE_BOSS.id);
    expect(result.mutationIds).toEqual(['crystal', 'void', 'wings']);
    expect(result.breakpointEvents).toHaveLength(3);
    expect(result.bossDefeated).toBe(true);
    expect(result.totalDamage).toBe(ACTIVE_BOSS.maxHp);
    expect(containsNonPlainValue(result)).toBe(false);
  });

  it('generates unique run IDs for separate runs and models', () => {
    const model = new CombatModel(0);
    const ids = new Set([model.runId]);
    model.reset(1);
    ids.add(model.runId);
    ids.add(new CombatModel(0).runId);
    expect(ids.size).toBe(3);
  });

  it('emits breakpoint, mutation, defeat and completion events once', () => {
    const events: GameDomainEvent[] = [];
    const model = new CombatModel(0, { emit: (event) => events.push(event) });
    const end = completeRun(model, 1000);
    model.completeMutation('wings', end + 1);
    model.finish(end);
    model.finish(end + 100);
    expect(events.filter((event) => event.type === 'RUN_STARTED')).toHaveLength(1);
    expect(events.filter((event) => event.type === 'BREAKPOINT_REACHED')).toHaveLength(3);
    expect(events.filter((event) => event.type === 'MUTATION_ACQUIRED')).toHaveLength(3);
    expect(events.filter((event) => event.type === 'BOSS_DEFEATED')).toHaveLength(1);
    expect(events.filter((event) => event.type === 'RUN_COMPLETED')).toHaveLength(1);
  });
});
