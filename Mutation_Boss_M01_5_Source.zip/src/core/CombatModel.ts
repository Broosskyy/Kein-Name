import { GAME_CONFIG } from '../config';
import { ACTIVE_BOSS, MUTATIONS, MUTATION_BY_ID } from '../content';
import type { GameDomainEvent } from './DomainEvents';
import type { AttackKind, AttackResult, Mutation, RunContract, RunPhase } from '../types';

export interface CombatModelOptions {
  emit?: (event: GameDomainEvent) => void;
  idGenerator?: () => string;
  wallClock?: () => string;
}

let runSequence = 0;

export class CombatModel {
  readonly maxHp: number = ACTIVE_BOSS.maxHp;
  runId = '';
  startedAtMs = 0;
  endedAtMs = 0;
  startedAtIso = '';
  bossHp: number = this.maxHp;
  phase: RunPhase = 'playing';
  totalDamage = 0;
  powerHits = 0;
  mutations = new Set<Mutation>();
  triggered = new Set<Mutation>();
  breakpointEvents: RunContract['breakpointEvents'] = [];
  lastPowerAtMs = Number.NEGATIVE_INFINITY;
  isPaused = false;
  private pausedAtMs = 0;
  private pausedDurationMs = 0;
  private completedResult?: RunContract;
  private readonly emitEvent: (event: GameDomainEvent) => void;
  private readonly idGenerator: () => string;
  private readonly wallClock: () => string;

  constructor(nowMs = 0, options: CombatModelOptions = {}) {
    this.emitEvent = options.emit ?? (() => undefined);
    this.idGenerator = options.idGenerator ?? (() => `run-${Date.now()}-${++runSequence}`);
    this.wallClock = options.wallClock ?? (() => new Date().toISOString());
    this.reset(nowMs);
  }

  reset(nowMs = 0): void {
    this.runId = this.idGenerator();
    this.startedAtMs = nowMs;
    this.endedAtMs = 0;
    this.startedAtIso = this.wallClock();
    this.bossHp = this.maxHp;
    this.phase = 'playing';
    this.totalDamage = 0;
    this.powerHits = 0;
    this.mutations.clear();
    this.triggered.clear();
    this.breakpointEvents = [];
    this.lastPowerAtMs = Number.NEGATIVE_INFINITY;
    this.isPaused = false;
    this.pausedAtMs = 0;
    this.pausedDurationMs = 0;
    this.completedResult = undefined;
    this.emitEvent({ type: 'RUN_STARTED', runId: this.runId, bossId: ACTIVE_BOSS.id });
  }

  pause(nowMs: number): void {
    if (this.isPaused || this.phase === 'result') return;
    this.isPaused = true;
    this.pausedAtMs = nowMs;
  }

  resume(nowMs: number): void {
    if (!this.isPaused) return;
    const pauseDuration = Math.max(0, nowMs - this.pausedAtMs);
    this.pausedDurationMs += pauseDuration;
    if (Number.isFinite(this.lastPowerAtMs)) this.lastPowerAtMs += pauseDuration;
    this.isPaused = false;
    this.pausedAtMs = 0;
  }

  elapsedMs(nowMs: number): number {
    const activePause = this.isPaused ? Math.max(0, nowMs - this.pausedAtMs) : 0;
    return Math.max(0, nowMs - this.startedAtMs - this.pausedDurationMs - activePause);
  }

  canPowerHit(nowMs: number): boolean {
    return !this.isPaused && this.phase === 'playing' && nowMs - this.lastPowerAtMs >= GAME_CONFIG.combat.powerCooldownMs;
  }

  powerCooldownRemaining(nowMs: number): number {
    const effectiveNow = this.isPaused ? this.pausedAtMs : nowMs;
    return Math.max(0, GAME_CONFIG.combat.powerCooldownMs - (effectiveNow - this.lastPowerAtMs));
  }

  attack(kind: AttackKind, nowMs: number): AttackResult {
    const hpBefore = this.bossHp;
    if (this.isPaused || this.phase !== 'playing' || (kind === 'power' && !this.canPowerHit(nowMs))) {
      return { accepted: false, kind, damage: 0, hpBefore, hpAfter: hpBefore };
    }

    let damage: number = kind === 'power' ? GAME_CONFIG.combat.powerDamage : GAME_CONFIG.combat.normalDamage;
    if (kind === 'voidEcho') damage = GAME_CONFIG.combat.normalDamage * GAME_CONFIG.combat.voidEchoMultiplier;
    for (const mutation of this.mutations) damage *= MUTATION_BY_ID[mutation].damageModifier;
    damage = Math.round(damage);

    if (kind === 'power') {
      this.lastPowerAtMs = nowMs;
      this.powerHits += 1;
    }

    this.bossHp = Math.max(0, this.bossHp - damage);
    const appliedDamage = hpBefore - this.bossHp;
    this.totalDamage += appliedDamage;
    this.emitEvent({ type: 'ATTACK_LANDED', runId: this.runId, atMs: this.elapsedMs(nowMs), attackKind: kind, damage: appliedDamage, bossHp: this.bossHp });

    const triggeredMutation = this.findTriggeredMutation();
    if (triggeredMutation) this.registerBreakpoint(triggeredMutation, nowMs);

    return { accepted: true, kind, damage: appliedDamage, hpBefore, hpAfter: this.bossHp, triggeredMutation };
  }

  debugForceBreakpoint(mutation: Mutation, nowMs: number): AttackResult {
    if (this.isPaused || this.phase !== 'playing') {
      return { accepted: false, kind: 'normal', damage: 0, hpBefore: this.bossHp, hpAfter: this.bossHp };
    }
    const targetIndex = MUTATIONS.findIndex((definition) => definition.id === mutation);
    for (let index = 0; index < targetIndex; index += 1) {
      const prior = MUTATIONS[index].id;
      this.triggered.add(prior);
      this.mutations.add(prior);
    }
    const hpBefore = this.bossHp;
    this.bossHp = Math.max(0, Math.floor(this.maxHp * MUTATION_BY_ID[mutation].breakpoint));
    const damage = Math.max(0, hpBefore - this.bossHp);
    this.totalDamage += damage;
    this.emitEvent({ type: 'ATTACK_LANDED', runId: this.runId, atMs: this.elapsedMs(nowMs), attackKind: 'normal', damage, bossHp: this.bossHp });
    this.registerBreakpoint(mutation, nowMs);
    return { accepted: true, kind: 'normal', damage, hpBefore, hpAfter: this.bossHp, triggeredMutation: mutation };
  }

  completeMutation(mutation: Mutation, nowMs = this.startedAtMs): void {
    if (!this.triggered.has(mutation) || this.mutations.has(mutation)) return;
    this.mutations.add(mutation);
    this.emitEvent({ type: 'MUTATION_ACQUIRED', runId: this.runId, atMs: this.elapsedMs(nowMs), mutationId: mutation });
    this.phase = mutation === 'wings' ? 'result' : 'playing';
  }

  finish(nowMs: number): RunContract {
    if (this.completedResult) return this.completedResult;
    this.endedAtMs = nowMs;
    this.completedResult = {
      schemaVersion: GAME_CONFIG.schemaVersion,
      clientVersion: GAME_CONFIG.clientVersion,
      runId: this.runId,
      bossId: ACTIVE_BOSS.id,
      startedAt: this.startedAtIso,
      endedAt: this.wallClock(),
      durationMs: this.elapsedMs(nowMs),
      totalDamage: this.totalDamage,
      powerHits: this.powerHits,
      mutationIds: MUTATIONS.map((mutation) => mutation.id).filter((mutation) => this.mutations.has(mutation)),
      breakpointEvents: this.breakpointEvents.map((event) => ({ ...event })),
      bossDefeated: this.bossHp === 0,
      qualityProfile: GAME_CONFIG.quality.active,
    };
    this.emitEvent({ type: 'RUN_COMPLETED', runId: this.runId, result: this.completedResult });
    return this.completedResult;
  }

  private registerBreakpoint(mutation: Mutation, nowMs: number): void {
    if (this.triggered.has(mutation)) return;
    const definition = MUTATION_BY_ID[mutation];
    this.triggered.add(mutation);
    this.phase = mutation === 'wings' ? 'finalizing' : 'breakpoint';
    const record = { mutationId: mutation, threshold: definition.breakpoint, bossHp: this.bossHp, elapsedMs: this.elapsedMs(nowMs) };
    this.breakpointEvents.push(record);
    this.emitEvent({ type: 'BREAKPOINT_REACHED', runId: this.runId, atMs: record.elapsedMs, mutationId: mutation, threshold: record.threshold, bossHp: record.bossHp });
    if (mutation === 'wings') {
      this.emitEvent({ type: 'BOSS_DEFEATED', runId: this.runId, atMs: record.elapsedMs, bossId: ACTIVE_BOSS.id });
    }
  }

  private findTriggeredMutation(): Mutation | undefined {
    const hpRatio = this.bossHp / this.maxHp;
    return MUTATIONS.find((mutation) => hpRatio <= mutation.breakpoint && !this.triggered.has(mutation.id))?.id;
  }
}
