import type { AttackKind, Mutation, RunContract } from '../types';

export type GameDomainEvent =
  | { type: 'RUN_STARTED'; runId: string; bossId: string }
  | { type: 'ATTACK_LANDED'; runId: string; atMs: number; attackKind: AttackKind; damage: number; bossHp: number }
  | { type: 'BREAKPOINT_REACHED'; runId: string; atMs: number; mutationId: Mutation; threshold: number; bossHp: number }
  | { type: 'MUTATION_ACQUIRED'; runId: string; atMs: number; mutationId: Mutation }
  | { type: 'BOSS_DEFEATED'; runId: string; atMs: number; bossId: string }
  | { type: 'RUN_COMPLETED'; runId: string; result: RunContract };

export type DomainEventListener = (event: GameDomainEvent) => void;

export class DomainEventBus {
  private readonly listeners = new Set<DomainEventListener>();

  emit(event: GameDomainEvent): void {
    for (const listener of this.listeners) listener(event);
  }

  subscribe(listener: DomainEventListener): () => void {
    this.listeners.add(listener);
    return () => this.listeners.delete(listener);
  }
}
