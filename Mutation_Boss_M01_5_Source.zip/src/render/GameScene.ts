import { Application, Container, Graphics, Sprite, Ticker } from 'pixi.js';
import { AssetRegistry, type AssetKey } from '../assets';
import { GAME_CONFIG } from '../config';
import { ACTIVE_BOSS } from '../content';
import { CombatModel } from '../core/CombatModel';
import type { DomainEventBus } from '../core/DomainEvents';
import type { GameAudio } from '../audio/AudioBus';
import type { AttackKind, Mutation } from '../types';
import { GameUI } from '../ui/GameUI';
import { EffectsLayer } from './EffectsLayer';
import { visualRandom } from './VisualRandom';

interface Projectile {
  view: Graphics;
  active: boolean;
  kind: AttackKind;
  elapsed: number;
  duration: number;
  sx: number;
  sy: number;
  tx: number;
  ty: number;
}

interface Transition {
  mutation: Mutation;
  elapsed: number;
  duration: number;
  absorbed: boolean;
}

export class GameScene {
  private readonly world = new Container();
  private readonly background = new Graphics();
  private readonly backgroundAsset?: Sprite;
  private readonly ambient = new Container();
  private readonly boss = new Container();
  private readonly bossShadow = new Graphics();
  private readonly bossFlash = new Graphics();
  private readonly bossCore = new Container();
  private readonly coreGlow = new Graphics();
  private readonly coreGem = new Graphics();
  private readonly creature = new Container();
  private readonly creatureBody = new Container();
  private readonly crystalMutation = new Container();
  private readonly voidMutation = new Container();
  private readonly wingMutation = new Container();
  private readonly essence = new Container();
  private readonly essenceGlow = new Graphics();
  private readonly essenceCore = new Graphics();
  private essenceAsset?: Sprite;
  private readonly effects = new EffectsLayer();
  private readonly projectiles: Projectile[] = [];
  private readonly motes: Graphics[] = [];
  private readonly temporaryTimers = new Set<number>();
  private readonly tick = (ticker: Ticker): void => this.update(Math.min(50, ticker.deltaMS));
  private readonly unsubscribeEvents: () => void;
  private resultTimeout?: number;
  private transition?: Transition;
  private elapsedMs = 0;
  private autoAttackMs = 350;
  private hitStopMs = 0;
  private shakeMs = 0;
  private shakeStrength = 0;
  private bossRecoil = 0;
  private creaturePunch = 0;
  private powerInFlight = false;
  private echoDelayMs = -1;
  private resultElapsed = 0;
  private width = 0;
  private height = 0;
  private portrait = true;
  private bossBaseScale = 1;
  private creatureBaseScale = 1;
  private bossBaseX = 0;
  private bossBaseY = 0;
  private creatureBaseX = 0;
  private creatureBaseY = 0;

  constructor(
    private readonly app: Application,
    private readonly ui: GameUI,
    private readonly audio: GameAudio,
    private readonly model: CombatModel,
    events: DomainEventBus,
    private readonly assets: AssetRegistry,
  ) {
    this.app.stage.addChild(this.world);
    const backgroundTexture = this.assets.texture('background.arena');
    if (backgroundTexture) this.backgroundAsset = new Sprite(backgroundTexture);
    this.world.addChild(this.background);
    if (this.backgroundAsset) this.world.addChild(this.backgroundAsset);
    this.world.addChild(this.ambient, this.boss, this.creature, this.essence, this.effects);
    this.createBoss();
    this.createCreature();
    this.createAmbientMotes();
    this.createProjectilePool();
    this.createEssence();
    this.resize();
    this.bindInput();
    this.unsubscribeEvents = events.subscribe((event) => {
      if (event.type === 'MUTATION_ACQUIRED') this.ui.setMutation(event.mutationId);
      if (event.type === 'RUN_COMPLETED') {
        window.clearTimeout(this.resultTimeout);
        this.resultTimeout = window.setTimeout(() => this.ui.showResult(event.result), 420);
      }
    });
    this.app.ticker.add(this.tick);
  }

  pause(nowMs: number): void {
    this.model.pause(nowMs);
    this.audio.pause();
    this.app.ticker.stop();
  }

  resume(nowMs: number): void {
    this.model.resume(nowMs);
    this.audio.resume();
    this.app.resize();
    this.resize();
    this.app.ticker.start();
  }

  destroy(): void {
    window.clearTimeout(this.resultTimeout);
    this.clearTemporaryTimers();
    this.unsubscribeEvents();
    this.app.ticker.remove(this.tick);
    this.clearProjectiles();
    this.effects.clearAll();
  }

  private createBoss(): void {
    this.bossShadow.ellipse(0, 165, 205, 48).fill({ color: 0x02030a, alpha: 0.62 });
    this.boss.addChild(this.bossShadow);
    const bossArt = new Container();

    const back = new Graphics()
      .poly([-208, 28, -256, 108, -204, 174, -144, 121, -135, 22]).fill(0x171a25)
      .poly([208, 28, 258, 108, 204, 174, 143, 121, 135, 22]).fill(0x171a25);
    const shoulders = new Graphics()
      .poly([-198, -76, -116, -126, -68, -74, -100, 12, -211, 30]).fill(0x303544)
      .poly([198, -76, 116, -126, 68, -74, 100, 12, 211, 30]).fill(0x303544)
      .poly([-198, -76, -151, -119, -116, -126, -141, -55]).fill(0x454c5d)
      .poly([198, -76, 151, -119, 116, -126, 141, -55]).fill(0x454c5d);
    const torso = new Graphics()
      .poly([-128, -88, -73, -137, 0, -116, 73, -137, 128, -88, 143, 57, 86, 146, 0, 169, -86, 146, -143, 57])
      .fill(0x262a38)
      .poly([-118, -76, -63, -119, -9, -99, -57, -25, -126, 9]).fill(0x3b4050)
      .poly([14, -99, 68, -119, 118, -76, 126, 9, 58, -25]).fill(0x323746)
      .poly([-93, 76, -26, 42, -5, 157, -86, 142]).fill(0x1d202c)
      .poly([93, 76, 26, 42, 5, 157, 86, 142]).fill(0x191c27);
    const head = new Graphics()
      .poly([-75, -195, -26, -225, 42, -216, 82, -175, 61, -111, 0, -89, -64, -116, -91, -169]).fill(0x303544)
      .poly([-70, -188, -25, -216, 0, -207, -31, -153, -78, -160]).fill(0x474d5e)
      .poly([0, -207, 39, -207, 72, -174, 53, -122, 6, -105]).fill(0x242936);
    const crown = new Graphics()
      .poly([-65, -200, -48, -252, -19, -211]).fill(0x242836)
      .poly([21, -215, 52, -253, 63, -197]).fill(0x242836);
    const face = new Graphics()
      .ellipse(-29, -163, 13, 8).fill(0xff6b2d)
      .ellipse(30, -163, 13, 8).fill(0xff6b2d)
      .ellipse(-29, -163, 6, 4).fill(0xffd08a)
      .ellipse(30, -163, 6, 4).fill(0xffd08a);
    const cracks = new Graphics()
      .moveTo(-64, -78).lineTo(-35, -47).lineTo(-49, -8).stroke({ color: 0xff5a24, width: 5, alpha: 0.75 })
      .moveTo(69, -72).lineTo(37, -39).lineTo(53, 3).stroke({ color: 0xff5a24, width: 4, alpha: 0.7 })
      .moveTo(-66, 61).lineTo(-37, 79).lineTo(-48, 116).stroke({ color: 0xff7b36, width: 4, alpha: 0.5 })
      .moveTo(70, 55).lineTo(44, 81).lineTo(54, 119).stroke({ color: 0xff7b36, width: 4, alpha: 0.5 });
    bossArt.addChild(back, shoulders, torso, head, crown, face, cracks);
    const heroTexture = this.assets.texture('boss.hero');
    if (heroTexture) {
      const hero = new Sprite(heroTexture);
      hero.anchor.set(0.5);
      const scale = 500 / Math.max(heroTexture.width, heroTexture.height);
      hero.scale.set(scale);
      this.boss.addChild(hero);
    } else {
      this.boss.addChild(bossArt);
    }

    this.coreGlow.circle(0, 0, 68).fill({ color: 0xff481f, alpha: 0.16 }).circle(0, 0, 45).fill({ color: 0xff762d, alpha: 0.2 });
    this.coreGem.poly([0, -46, 34, -16, 25, 30, 0, 48, -28, 28, -34, -17]).fill(0xff5c26)
      .poly([0, -34, 23, -12, 16, 20, 0, 34, -18, 19, -23, -12]).fill(0xffc15a)
      .circle(-7, -9, 7).fill({ color: 0xffffff, alpha: 0.75 });
    this.bossCore.position.set(ACTIVE_BOSS.weakpoint.x, ACTIVE_BOSS.weakpoint.y);
    this.bossCore.addChild(this.coreGlow, this.coreGem);
    this.boss.addChild(this.bossCore);

    this.bossFlash
      .poly([-126, -90, -62, -138, 0, -116, 62, -138, 126, -90, 142, 60, 80, 146, 0, 172, -80, 146, -142, 60])
      .fill({ color: 0xffffff, alpha: 0.8 });
    this.bossFlash.alpha = 0;
    this.boss.addChild(this.bossFlash);
  }

  private createCreature(): void {
    const shadow = new Graphics().ellipse(0, 69, 79, 22).fill({ color: 0x02030b, alpha: 0.5 });
    this.creature.addChild(shadow, this.wingMutation, this.creatureBody);

    const feet = new Graphics()
      .ellipse(-46, 49, 29, 20).fill(0xd9dcff)
      .ellipse(43, 53, 27, 18).fill(0xc4c8f2);
    const body = new Graphics()
      .moveTo(-79, 35).bezierCurveTo(-92, -20, -65, -76, -16, -91)
      .bezierCurveTo(18, -110, 67, -79, 79, -30)
      .bezierCurveTo(94, 22, 70, 65, 17, 70)
      .bezierCurveTo(-27, 78, -67, 66, -79, 35).fill(0xe4e5ff)
      .moveTo(-66, 6).bezierCurveTo(-54, -46, -19, -78, 16, -79)
      .bezierCurveTo(-7, -57, -19, -26, -18, 7).fill({ color: 0xffffff, alpha: 0.36 });
    const earFins = new Graphics()
      .poly([-63, -51, -89, -78, -78, -31]).fill(0xc6cbf4)
      .poly([57, -59, 78, -85, 79, -37]).fill(0xb8bde9);
    const face = new Graphics()
      .ellipse(-27, -17, 11, 17).fill(0x15182b)
      .ellipse(27, -19, 11, 17).fill(0x15182b)
      .circle(-30, -23, 4).fill(0xffffff)
      .circle(24, -25, 4).fill(0xffffff)
      .moveTo(-7, 12).quadraticCurveTo(0, 17, 9, 10).stroke({ color: 0x474a70, width: 3 });
    this.creatureBody.addChild(feet, earFins, body, this.crystalMutation, this.voidMutation, face);

    this.crystalMutation.addChild(
      new Graphics()
        .poly([-36, -65, -20, -130, -2, -69]).fill(0x57dfff)
        .poly([-6, -73, 19, -143, 35, -62]).fill(0x806cff)
        .poly([31, -56, 63, -109, 68, -40]).fill(0x39c9ff)
        .poly([-69, -6, -99, -47, -78, 13]).fill(0x55d9ff),
    );
    this.replaceWithAsset(this.crystalMutation, 'mutations.crystal', 150);
    this.crystalMutation.visible = false;
    this.crystalMutation.scale.set(0.01);

    this.voidMutation.addChild(
      new Graphics()
        .circle(-51, 16, 8).fill(0xc964ff).circle(48, 8, 8).fill(0xc964ff)
        .circle(-51, 16, 3).fill(0xffffff).circle(48, 8, 3).fill(0xffffff)
        .moveTo(-35, 38).quadraticCurveTo(0, 54, 39, 34).stroke({ color: 0x9d4cff, width: 5, alpha: 0.8 })
        .circle(0, 0, 104).stroke({ color: 0x9d4cff, width: 4, alpha: 0.2 }),
    );
    this.replaceWithAsset(this.voidMutation, 'mutations.void', 190);
    this.voidMutation.visible = false;
    this.voidMutation.alpha = 0;

    this.wingMutation.addChild(
      new Graphics()
        .moveTo(-42, -29).bezierCurveTo(-97, -99, -157, -88, -143, -16).bezierCurveTo(-126, -41, -102, -15, -77, 13).lineTo(-38, 30).fill(0x6730ad)
        .moveTo(42, -29).bezierCurveTo(97, -99, 157, -88, 143, -16).bezierCurveTo(126, -41, 102, -15, 77, 13).lineTo(38, 30).fill(0x6730ad)
        .moveTo(-43, -27).bezierCurveTo(-97, -77, -129, -66, -126, -29).stroke({ color: 0xc45cff, width: 6, alpha: 0.8 })
        .moveTo(43, -27).bezierCurveTo(97, -77, 129, -66, 126, -29).stroke({ color: 0xc45cff, width: 6, alpha: 0.8 }),
    );
    this.replaceWithAsset(this.wingMutation, 'mutations.wings', 300);
    this.wingMutation.visible = false;
    this.wingMutation.scale.set(0.01);
  }

  private createAmbientMotes(): void {
    for (let index = 0; index < 18; index += 1) {
      const mote = new Graphics().circle(0, 0, visualRandom.range(1.5, 4)).fill({ color: index % 2 ? 0xff8b46 : 0x7668ff, alpha: 0.45 });
      mote.x = visualRandom.next();
      mote.y = visualRandom.next();
      mote.alpha = visualRandom.range(0.2, 0.7);
      this.ambient.addChild(mote);
      this.motes.push(mote);
    }
  }

  private createProjectilePool(): void {
    for (let index = 0; index < GAME_CONFIG.quality[GAME_CONFIG.quality.active].maxProjectiles; index += 1) {
      const view = new Graphics();
      view.visible = false;
      this.world.addChild(view);
      this.projectiles.push({ view, active: false, kind: 'normal', elapsed: 0, duration: 0, sx: 0, sy: 0, tx: 0, ty: 0 });
    }
    this.world.setChildIndex(this.effects, this.world.children.length - 1);
  }

  private createEssence(): void {
    this.essenceGlow.circle(0, 0, 34).fill({ color: 0x70dcff, alpha: 0.15 });
    this.essenceCore.poly([0, -19, 15, -5, 9, 17, -10, 16, -16, -4]).fill(0x7ce8ff);
    this.essence.addChild(this.essenceGlow, this.essenceCore);
    this.essence.visible = false;
  }

  private replaceWithAsset(container: Container, key: AssetKey, targetWidth: number): void {
    const texture = this.assets.texture(key);
    if (!texture) return;
    container.removeChildren();
    const sprite = new Sprite(texture);
    sprite.anchor.set(0.5);
    const scale = targetWidth / Math.max(1, texture.width);
    sprite.scale.set(scale);
    container.addChild(sprite);
  }

  private bindInput(): void {
    this.ui.bindPower(() => {
      this.audio.unlock();
      this.requestPowerHit();
    });
    this.ui.bindRetry(() => this.reset());
    this.ui.bindDebug((action) => {
      if (action === 'restart') {
        this.reset();
        return;
      }
      const mutation: Mutation = action === '70' ? 'crystal' : action === '40' ? 'void' : 'wings';
      const result = this.model.debugForceBreakpoint(mutation, performance.now());
      if (result.accepted) {
        this.syncMutationVisuals();
        this.showImpact(result.kind, result.damage, result.triggeredMutation);
        if (result.triggeredMutation) this.beginTransition(result.triggeredMutation);
      }
    });
  }

  private requestPowerHit(): void {
    if (this.powerInFlight || !this.model.canPowerHit(performance.now())) return;
    this.powerInFlight = true;
    this.creaturePunch = 1.4;
    this.audio.play('powerHit');
    this.schedule(() => {
      if (this.model.phase === 'playing') this.launchProjectile('power');
      else this.powerInFlight = false;
    }, 120);
  }

  private launchProjectile(kind: AttackKind): void {
    const projectile = this.projectiles.find((candidate) => !candidate.active);
    if (!projectile || this.model.phase !== 'playing') return;
    projectile.active = true;
    projectile.kind = kind;
    projectile.elapsed = 0;
    projectile.duration = kind === 'power' ? GAME_CONFIG.timing.powerProjectileMs : kind === 'voidEcho' ? 180 : GAME_CONFIG.timing.normalProjectileMs;
    projectile.sx = this.creature.x;
    projectile.sy = this.creature.y - 45 * this.creatureBaseScale;
    projectile.tx = this.boss.x;
    projectile.ty = this.boss.y + ACTIVE_BOSS.weakpoint.y * this.bossBaseScale;
    projectile.view.clear();
    if (kind === 'power') {
      projectile.view.circle(0, 0, 23).fill({ color: 0xffd65b, alpha: 0.2 })
        .poly([-30, 0, -8, -14, 24, 0, -8, 14]).fill(0xffef97)
        .circle(7, 0, 8).fill(0xffffff);
    } else if (kind === 'voidEcho') {
      projectile.view.circle(0, 0, 19).fill({ color: 0x7a2dbb, alpha: 0.22 })
        .circle(0, 0, 9).stroke({ color: 0xd475ff, width: 4, alpha: 0.9 });
    } else if (this.model.mutations.has('crystal')) {
      projectile.view.poly([-17, 0, -4, -12, 19, 0, -4, 12]).fill(0x7cecff)
        .poly([-6, -4, 14, 0, -6, 4]).fill(0xffffff);
    } else {
      projectile.view.circle(0, 0, 8).fill(0xe5e8ff).circle(0, 0, 14).stroke({ color: 0x9fa9ff, width: 3, alpha: 0.42 });
    }
    projectile.view.position.set(projectile.sx, projectile.sy);
    projectile.view.visible = true;
    this.creaturePunch = Math.max(this.creaturePunch, kind === 'power' ? 1.2 : 0.55);
    if (kind === 'normal') this.audio.play('normalAttack');
  }

  private update(deltaMs: number): void {
    const now = performance.now();
    this.elapsedMs = this.model.elapsedMs(now);
    this.ui.update(
      this.model.bossHp,
      this.model.maxHp,
      this.elapsedMs,
      this.model.powerCooldownRemaining(now),
      this.model.phase === 'playing' && !this.powerInFlight,
    );

    if (this.hitStopMs > 0) {
      this.hitStopMs -= deltaMs;
      return;
    }

    this.animateScene(deltaMs, now);
    this.effects.update(deltaMs);
    this.updateProjectiles(deltaMs, now);

    if (this.model.phase === 'playing') {
      this.autoAttackMs -= deltaMs;
      if (this.autoAttackMs <= 0) {
        this.autoAttackMs += GAME_CONFIG.combat.attackIntervalMs;
        this.launchProjectile('normal');
      }
      if (this.echoDelayMs >= 0) {
        this.echoDelayMs -= deltaMs;
        if (this.echoDelayMs <= 0) {
          this.echoDelayMs = -1;
          this.launchProjectile('voidEcho');
        }
      }
    }
    if (this.transition) this.updateTransition(deltaMs);
    if (this.model.phase === 'result') this.updateResult(deltaMs);
  }

  private animateScene(deltaMs: number, now: number): void {
    const seconds = now / 1000;
    const breath = 1 + Math.sin(seconds * 1.45) * 0.009;
    this.boss.scale.set(this.bossBaseScale * breath * (1 + this.bossRecoil * 0.018), this.bossBaseScale * (2 - breath) * (1 - this.bossRecoil * 0.012));
    this.boss.x = this.bossBaseX + this.bossRecoil * 8;
    this.boss.y = this.bossBaseY + Math.sin(seconds * 1.45) * 2 * this.bossBaseScale;
    this.bossRecoil = Math.max(0, this.bossRecoil - deltaMs / 130);
    this.bossFlash.alpha = Math.max(0, this.bossFlash.alpha - deltaMs / 95);
    const corePulse = 1 + Math.sin(seconds * 4.2) * 0.11;
    this.coreGlow.scale.set(corePulse);
    this.coreGlow.alpha = 0.7 + Math.sin(seconds * 4.2) * 0.18;

    const creatureBreath = 1 + Math.sin(seconds * 3.1) * 0.018;
    const punch = Math.max(0, this.creaturePunch);
    this.creature.scale.set(
      this.creatureBaseScale * (creatureBreath + punch * 0.08),
      this.creatureBaseScale * (2 - creatureBreath - punch * 0.11),
    );
    this.creature.y = this.creatureBaseY + Math.sin(seconds * 2.4) * 3 + punch * 7;
    this.creature.rotation = Math.sin(seconds * 2) * 0.012 - punch * 0.025;
    this.creaturePunch = Math.max(0, this.creaturePunch - deltaMs / 190);
    if (this.wingMutation.visible) this.wingMutation.rotation = Math.sin(seconds * 4.2) * 0.025;

    this.shakeMs = Math.max(0, this.shakeMs - deltaMs);
    if (this.shakeMs > 0) {
      this.world.position.set(visualRandom.centered(this.shakeStrength), visualRandom.centered(this.shakeStrength));
    } else {
      this.world.position.set(0, 0);
    }

    this.motes.forEach((mote, index) => {
      mote.y -= deltaMs * (0.006 + (index % 4) * 0.002);
      mote.alpha = 0.18 + (Math.sin(seconds * 1.4 + index) + 1) * 0.18;
      if (mote.y < -10) mote.y = this.height + 10;
    });
  }

  private updateProjectiles(deltaMs: number, now: number): void {
    for (const projectile of this.projectiles) {
      if (!projectile.active) continue;
      projectile.elapsed += deltaMs;
      const progress = Math.min(1, projectile.elapsed / projectile.duration);
      const eased = 1 - Math.pow(1 - progress, 2);
      projectile.view.x = lerp(projectile.sx, projectile.tx, eased);
      projectile.view.y = lerp(projectile.sy, projectile.ty, eased) - Math.sin(progress * Math.PI) * (projectile.kind === 'power' ? 75 : 42);
      projectile.view.rotation += deltaMs * 0.012;
      if (projectile.kind === 'power' && progress > 0.12) {
        this.effects.burst(projectile.view.x - 15, projectile.view.y + 5, 0xffd65b, 1, 0.25);
      }
      if (progress >= 1) {
        projectile.active = false;
        projectile.view.visible = false;
        const result = this.model.attack(projectile.kind, now);
        if (projectile.kind === 'power') this.powerInFlight = false;
        if (!result.accepted) continue;
        this.showImpact(projectile.kind, result.damage, result.triggeredMutation);
        if (this.model.mutations.has('void') && projectile.kind !== 'voidEcho' && !result.triggeredMutation && this.model.phase === 'playing') {
          this.echoDelayMs = GAME_CONFIG.combat.voidEchoDelayMs;
        }
        if (result.triggeredMutation) this.beginTransition(result.triggeredMutation);
      }
    }
  }

  private showImpact(kind: AttackKind, damage: number, mutation?: Mutation): void {
    const x = this.bossBaseX;
    const y = this.bossBaseY + ACTIVE_BOSS.weakpoint.y * this.bossBaseScale;
    const power = kind === 'power';
    const echo = kind === 'voidEcho';
    const color = echo ? 0xc96cff : this.model.mutations.has('crystal') ? 0x7cecff : power ? 0xffe67b : 0xffffff;
    this.effects.burst(x, y, color, power ? 24 : echo ? 10 : 8, power ? 1.2 : 0.72);
    this.effects.damageNumber(x, y, damage, power, color);
    if (power) this.effects.shockwave(x, y, 0xffdb62, 1.15);
    this.bossRecoil = power ? 1.4 : echo ? 0.5 : 0.72;
    this.bossFlash.alpha = power ? 0.72 : 0.38;
    this.hitStopMs = power ? GAME_CONFIG.timing.powerHitStopMs : GAME_CONFIG.timing.normalHitStopMs;
    this.shake(power ? 300 : 130, power ? 12 : 4);
    this.audio.play('bossImpact');
    if (mutation === 'wings') this.hitStopMs = GAME_CONFIG.timing.finalHitStopMs;
  }

  private beginTransition(mutation: Mutation): void {
    this.clearProjectiles();
    this.powerInFlight = false;
    this.echoDelayMs = -1;
    this.transition = {
      mutation,
      elapsed: 0,
      duration: mutation === 'wings' ? GAME_CONFIG.timing.finalDurationMs : GAME_CONFIG.timing.breakpointDurationMs,
      absorbed: false,
    };
    const data = mutationVisual(mutation);
    this.essenceAsset?.destroy();
    this.essenceAsset = undefined;
    const lootTexture = this.assets.texture(`loot.${mutation}` as AssetKey);
    this.essenceCore.visible = !lootTexture;
    if (lootTexture) {
      this.essenceAsset = new Sprite(lootTexture);
      this.essenceAsset.anchor.set(0.5);
      const scale = 46 / Math.max(1, lootTexture.width);
      this.essenceAsset.scale.set(scale);
      this.essence.addChild(this.essenceAsset);
    }
    this.essenceCore.clear().poly([0, -19, 15, -5, 9, 17, -10, 16, -16, -4]).fill(data.color);
    this.essenceGlow.clear().circle(0, 0, 38).fill({ color: data.color, alpha: 0.2 }).circle(0, 0, 24).stroke({ color: data.light, width: 4, alpha: 0.65 });
    this.essence.position.set(this.bossBaseX, this.bossBaseY);
    this.essence.scale.set(0.1);
    this.essence.visible = true;
    this.ui.announce(data.title, data.subtitle, data.css);
    this.audio.play(mutation === 'wings' ? 'finalReveal' : 'breakpoint');
    this.bossFlash.alpha = 1;
    this.bossRecoil = mutation === 'wings' ? 2.4 : 1.8;
    this.effects.shockwave(this.bossBaseX, this.bossBaseY, data.color, mutation === 'wings' ? 1.7 : 1.2);
    this.effects.burst(this.bossBaseX, this.bossBaseY, data.color, mutation === 'wings' ? 54 : 26, mutation === 'wings' ? 1.7 : 1.05);
    this.shake(mutation === 'wings' ? 650 : 380, mutation === 'wings' ? 20 : 13);
  }

  private updateTransition(deltaMs: number): void {
    const transition = this.transition;
    if (!transition) return;
    transition.elapsed += deltaMs;
    const progress = transition.elapsed / transition.duration;
    const flyStart = transition.mutation === 'wings' ? 0.28 : 0.2;
    const flyEnd = transition.mutation === 'wings' ? 0.68 : 0.63;
    const bossX = this.bossBaseX;
    const bossY = this.bossBaseY;
    const creatureX = this.creatureBaseX;
    const creatureY = this.creatureBaseY - 30 * this.creatureBaseScale;

    if (progress < flyStart) {
      this.essence.position.set(bossX, bossY);
      this.essence.scale.set(easeOutBack(Math.max(0, progress / flyStart)));
    } else if (progress < flyEnd) {
      const local = easeInOut((progress - flyStart) / (flyEnd - flyStart));
      this.essence.x = lerp(bossX, creatureX, local);
      this.essence.y = lerp(bossY, creatureY, local) - Math.sin(local * Math.PI) * Math.min(150, this.height * 0.12);
      this.essence.scale.set(1 + Math.sin(local * Math.PI) * 0.35);
      this.essence.rotation += deltaMs * 0.007;
      this.effects.burst(this.essence.x, this.essence.y, mutationVisual(transition.mutation).color, 1, 0.18);
    } else if (!transition.absorbed) {
      transition.absorbed = true;
      this.essence.visible = false;
      this.creaturePunch = 2.1;
      this.effects.shockwave(creatureX, creatureY, mutationVisual(transition.mutation).color, 0.9);
      this.effects.burst(creatureX, creatureY, mutationVisual(transition.mutation).light, 32, 0.9);
      this.revealMutation(transition.mutation);
      this.audio.play('essenceAbsorb');
      this.schedule(() => this.audio.play('mutation'), 180);
    }

    if (transition.absorbed) {
      const local = Math.min(1, (progress - flyEnd) / Math.max(0.001, 1 - flyEnd));
      this.animateMutationReveal(transition.mutation, local);
    }

    if (progress >= 1) {
      this.model.completeMutation(transition.mutation, performance.now());
      this.transition = undefined;
      this.autoAttackMs = 440;
      if (this.model.phase === 'result') {
        this.model.finish(performance.now());
        this.resultElapsed = 0;
      }
    }
  }

  private revealMutation(mutation: Mutation): void {
    if (mutation === 'crystal') {
      this.crystalMutation.visible = true;
      this.crystalMutation.scale.set(0.01);
    } else if (mutation === 'void') {
      this.voidMutation.visible = true;
      this.voidMutation.alpha = 0;
    } else {
      this.wingMutation.visible = true;
      this.wingMutation.scale.set(0.01);
    }
  }

  private syncMutationVisuals(): void {
    if (this.model.mutations.has('crystal')) {
      this.crystalMutation.visible = true;
      this.crystalMutation.scale.set(1);
      this.ui.setMutation('crystal');
    }
    if (this.model.mutations.has('void')) {
      this.voidMutation.visible = true;
      this.voidMutation.alpha = 1;
      this.ui.setMutation('void');
    }
  }

  private animateMutationReveal(mutation: Mutation, progress: number): void {
    const scale = easeOutBack(progress);
    if (mutation === 'crystal') this.crystalMutation.scale.set(scale);
    else if (mutation === 'void') this.voidMutation.alpha = Math.min(1, progress * 1.8);
    else this.wingMutation.scale.set(scale);
  }

  private updateResult(deltaMs: number): void {
    this.resultElapsed += deltaMs;
    const t = Math.min(1, this.resultElapsed / 800);
    const targetX = this.width / 2;
    const targetY = this.height * (this.portrait ? 0.47 : 0.48);
    this.creature.x = lerp(this.creatureBaseX, targetX, easeInOut(t));
    this.creature.y = lerp(this.creatureBaseY, targetY, easeInOut(t));
    const revealScale = this.creatureBaseScale * (this.portrait ? 1.75 : 1.5);
    const currentScale = lerp(this.creatureBaseScale, revealScale, easeOutBack(t));
    this.creature.scale.set(currentScale);
    this.boss.alpha = Math.max(0.05, 1 - t * 0.93);
    this.background.alpha = 1 - t * 0.28;
  }

  private reset(): void {
    window.clearTimeout(this.resultTimeout);
    this.clearTemporaryTimers();
    this.model.reset(performance.now());
    this.elapsedMs = 0;
    this.autoAttackMs = 350;
    this.hitStopMs = 0;
    this.shakeMs = 0;
    this.bossRecoil = 0;
    this.creaturePunch = 0;
    this.powerInFlight = false;
    this.echoDelayMs = -1;
    this.transition = undefined;
    this.resultElapsed = 0;
    this.boss.alpha = 1;
    this.background.alpha = 1;
    this.crystalMutation.visible = false;
    this.crystalMutation.scale.set(0.01);
    this.voidMutation.visible = false;
    this.voidMutation.alpha = 0;
    this.wingMutation.visible = false;
    this.wingMutation.scale.set(0.01);
    this.essence.visible = false;
    this.clearProjectiles();
    this.effects.clearAll();
    this.ui.reset();
    this.resize();
  }

  private clearProjectiles(): void {
    for (const projectile of this.projectiles) {
      projectile.active = false;
      projectile.view.visible = false;
    }
  }

  private schedule(callback: () => void, delayMs: number): void {
    const timer = window.setTimeout(() => {
      this.temporaryTimers.delete(timer);
      callback();
    }, delayMs);
    this.temporaryTimers.add(timer);
  }

  private clearTemporaryTimers(): void {
    for (const timer of this.temporaryTimers) window.clearTimeout(timer);
    this.temporaryTimers.clear();
  }

  private shake(durationMs: number, strength: number): void {
    this.shakeMs = Math.max(this.shakeMs, durationMs);
    this.shakeStrength = Math.max(this.shakeStrength, strength);
  }

  resize(): void {
    this.width = this.app.screen.width;
    this.height = this.app.screen.height;
    this.portrait = this.height >= this.width;
    this.background.clear()
      .rect(0, 0, this.width, this.height).fill(0x090b16)
      .circle(this.width * (this.portrait ? 0.5 : 0.68), this.height * 0.33, Math.max(this.width, this.height) * 0.35).fill({ color: 0x23172e, alpha: 0.36 })
      .rect(0, this.height * 0.68, this.width, this.height * 0.32).fill({ color: 0x111522, alpha: 0.95 });
    for (let line = 0; line < 6; line += 1) {
      const y = this.height * (0.7 + line * 0.055);
      this.background.moveTo(0, y).lineTo(this.width, y).stroke({ color: 0x65708c, width: 1, alpha: 0.11 });
    }
    if (this.backgroundAsset) {
      const scale = Math.max(this.width / this.backgroundAsset.texture.width, this.height / this.backgroundAsset.texture.height);
      this.backgroundAsset.scale.set(scale);
      this.backgroundAsset.position.set((this.width - this.backgroundAsset.width) / 2, (this.height - this.backgroundAsset.height) / 2);
    }
    this.bossBaseScale = this.portrait ? Math.min(1.05, this.width / 540) : Math.min(1.02, this.height / 600);
    this.creatureBaseScale = this.portrait ? Math.min(0.86, this.width / 620) : Math.min(0.82, this.height / 760);
    this.bossBaseX = this.portrait ? this.width * 0.5 : this.width * 0.66;
    this.bossBaseY = this.portrait ? this.height * 0.37 : this.height * 0.43;
    this.creatureBaseX = this.portrait ? this.width * 0.5 : this.width * 0.27;
    this.creatureBaseY = this.portrait ? this.height * 0.78 : this.height * 0.7;
    this.boss.position.set(this.bossBaseX, this.bossBaseY);
    this.boss.scale.set(this.bossBaseScale);
    this.creature.position.set(this.creatureBaseX, this.creatureBaseY);
    this.creature.scale.set(this.creatureBaseScale);
    this.motes.forEach((mote, index) => {
      mote.x = ((index * 83) % 100) / 100 * this.width;
      mote.y = ((index * 47) % 100) / 100 * this.height;
    });
  }
}

function mutationVisual(mutation: Mutation): { color: number; light: number; css: string; title: string; subtitle: string } {
  if (mutation === 'crystal') return { color: 0x5ddfff, light: 0xd9faff, css: '#68e4ff', title: 'CORE FRACTURED', subtitle: 'CRYSTAL ESSENCE ABSORBED' };
  if (mutation === 'void') return { color: 0x9e48e8, light: 0xe6a7ff, css: '#bc67ff', title: 'VOID AWAKENED', subtitle: 'ECHO STRIKE UNLOCKED' };
  return { color: 0xffc65a, light: 0xfff0ae, css: '#ffd36b', title: 'FINAL BREAK', subtitle: 'WING ESSENCE CLAIMED' };
}

function lerp(from: number, to: number, progress: number): number {
  return from + (to - from) * progress;
}

function easeInOut(value: number): number {
  return value < 0.5 ? 2 * value * value : 1 - Math.pow(-2 * value + 2, 2) / 2;
}

function easeOutBack(value: number): number {
  const c1 = 1.70158;
  const c3 = c1 + 1;
  return 1 + c3 * Math.pow(value - 1, 3) + c1 * Math.pow(value - 1, 2);
}
