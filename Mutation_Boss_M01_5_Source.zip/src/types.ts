export type Mutation = 'crystal' | 'void' | 'wings';
export type RunPhase = 'playing' | 'breakpoint' | 'finalizing' | 'result';
export type AttackKind = 'normal' | 'power' | 'voidEcho';

export interface AttackResult {
  accepted: boolean;
  kind: AttackKind;
  damage: number;
  hpBefore: number;
  hpAfter: number;
  triggeredMutation?: Mutation;
}

export interface RunBreakpointRecord {
  mutationId: Mutation;
  threshold: number;
  bossHp: number;
  elapsedMs: number;
}

export interface RunContract {
  schemaVersion: number;
  clientVersion: string;
  runId: string;
  bossId: string;
  startedAt: string;
  endedAt: string;
  durationMs: number;
  totalDamage: number;
  powerHits: number;
  mutationIds: Mutation[];
  breakpointEvents: RunBreakpointRecord[];
  bossDefeated: boolean;
  qualityProfile: string;
}

export type RunResult = RunContract;
