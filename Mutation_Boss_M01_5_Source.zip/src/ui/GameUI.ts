import { GAME_CONFIG } from '../config';
import type { Mutation, RunResult } from '../types';

type DebugAction = '70' | '40' | '0' | 'restart';

export class GameUI {
  private readonly hpFill = requiredElement<HTMLElement>('hp-fill');
  private readonly hpShine = requiredElement<HTMLElement>('hp-shine');
  private readonly timer = requiredElement<HTMLElement>('timer');
  private readonly powerButton = requiredElement<HTMLButtonElement>('power-button');
  private readonly powerStatus = requiredElement<HTMLElement>('power-status');
  private readonly powerCooldown = requiredElement<HTMLElement>('power-cooldown');
  private readonly announcement = requiredElement<HTMLElement>('announcement');
  private readonly resultPanel = requiredElement<HTMLElement>('result-panel');
  private readonly debugPanel = requiredElement<HTMLElement>('debug-panel');
  private onPower?: () => void;
  private onRetry?: () => void;
  private onDebug?: (action: DebugAction) => void;
  private announcementTimeout?: number;

  constructor() {
    this.powerButton.addEventListener('pointerdown', (event) => {
      event.preventDefault();
      this.onPower?.();
    });
    requiredElement<HTMLButtonElement>('retry-button').addEventListener('click', () => this.onRetry?.());
    this.debugPanel.querySelectorAll<HTMLButtonElement>('button[data-debug]').forEach((button) => {
      button.addEventListener('click', () => this.onDebug?.(button.dataset.debug as DebugAction));
    });
    window.addEventListener('keydown', (event) => {
      if (event.key === '`' || event.key.toLowerCase() === 'd') this.debugPanel.classList.toggle('visible');
    });
    if (new URLSearchParams(location.search).has('debug')) this.debugPanel.classList.add('visible');
  }

  bindPower(callback: () => void): void { this.onPower = callback; }
  bindRetry(callback: () => void): void { this.onRetry = callback; }
  bindDebug(callback: (action: DebugAction) => void): void { this.onDebug = callback; }

  update(hp: number, maxHp: number, elapsedMs: number, cooldownMs: number, playing: boolean): void {
    const hpRatio = Math.max(0, hp / maxHp);
    this.hpFill.style.transform = `scaleX(${hpRatio})`;
    this.hpShine.style.left = `${hpRatio * 100}%`;
    this.timer.textContent = formatTime(elapsedMs);
    const cooldownRatio = Math.min(1, cooldownMs / GAME_CONFIG.combat.powerCooldownMs);
    const ready = cooldownMs <= 0 && playing;
    this.powerCooldown.style.transform = `scaleY(${cooldownRatio})`;
    this.powerStatus.textContent = ready ? 'READY' : playing ? `${(cooldownMs / 1000).toFixed(1)}s` : 'LOCKED';
    this.powerButton.disabled = !ready;
    this.powerButton.classList.toggle('ready', ready);
  }

  setMutation(mutation: Mutation, active = true): void {
    requiredElement(`mut-${mutation}`).classList.toggle('active', active);
    requiredElement(`bp-${mutation}`).classList.toggle('broken', active);
  }

  announce(title: string, subtitle: string, color: string, durationMs = 1400): void {
    const strong = this.announcement.querySelector('strong');
    const span = this.announcement.querySelector('span');
    if (strong) strong.textContent = title;
    if (span) span.textContent = subtitle;
    this.announcement.style.setProperty('--accent', color);
    this.announcement.classList.remove('show');
    void this.announcement.offsetWidth;
    this.announcement.classList.add('show');
    window.clearTimeout(this.announcementTimeout);
    this.announcementTimeout = window.setTimeout(() => this.announcement.classList.remove('show'), durationMs);
  }

  showResult(result: RunResult): void {
    requiredElement('result-time').textContent = formatTime(result.durationMs);
    requiredElement('result-damage').textContent = Math.round(result.totalDamage).toLocaleString();
    requiredElement('result-power').textContent = String(result.powerHits);
    this.resultPanel.classList.add('visible');
    this.resultPanel.setAttribute('aria-hidden', 'false');
    document.body.classList.add('result-open');
  }

  reset(): void {
    this.resultPanel.classList.remove('visible');
    this.resultPanel.setAttribute('aria-hidden', 'true');
    document.body.classList.remove('result-open');
    this.announcement.classList.remove('show');
    window.clearTimeout(this.announcementTimeout);
    (['crystal', 'void', 'wings'] as Mutation[]).forEach((mutation) => this.setMutation(mutation, false));
  }
}

function requiredElement<T extends HTMLElement = HTMLElement>(id: string): T {
  const element = document.getElementById(id);
  if (!element) throw new Error(`Missing UI element #${id}`);
  return element as T;
}

function formatTime(milliseconds: number): string {
  const totalSeconds = Math.max(0, Math.floor(milliseconds / 1000));
  return `${String(Math.floor(totalSeconds / 60)).padStart(2, '0')}:${String(totalSeconds % 60).padStart(2, '0')}`;
}
